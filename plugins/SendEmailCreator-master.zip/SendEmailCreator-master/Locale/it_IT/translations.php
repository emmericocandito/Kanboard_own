<?php

return [
  'Email subject' => 'Oggetto dell\'email',
  'Duration in days' => 'Durata in giorni',
  'Send a task by email to creator' => 'Invia un\'attività via e-mail al creatore',
  'Send a task by email to assignee' => 'Invia un\'attività via e-mail all\'assegnatario',
  'Send email notification of impending due date' => 'Invia un\'e-mail di notifica di imminente scadenza',
  'Send email notification of impending subtask due date' => 'Invia notifica e-mail della data di scadenza della sottoattività imminente',
  'Send new comments on a task by email' => 'Invia nuovi commenti su un\'attività via e-mail'
];
