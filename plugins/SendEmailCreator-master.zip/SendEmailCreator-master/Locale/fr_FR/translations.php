<?php

return [
  'Email subject' => 'Sujet du mail',
  'Duration in days' => 'Durée en jours',
  'Send a task by email to creator' => 'Envoyer une tâche par email au créateur',
  'Send a task by email to assignee' => 'Envoyer une tâche par email à l\'assigné',
  'Send email notification of impending due date' => 'Envoyer une notification par email lorsque la date d\'échéance est proche',
  'Send email notification of impending subtask due date' => 'Envoyer une notification par email lorsque la date d\'échéance d\'une sous-tâche est proche',
  'Send new comments on a task by email' => 'Envoyer les nouveaux commentaires sur une tâche par email',
  'Include Task Title and ID in subject line?' => 'Inclure le titre et l\'id de la tâche dans le sujet du mail',
];
