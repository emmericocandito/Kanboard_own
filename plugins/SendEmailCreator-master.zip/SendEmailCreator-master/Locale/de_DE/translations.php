<?php

return array(
  'Email subject' => 'E-Mail Betreff',
  'Duration in days' => 'Laufzeit in Tagen',
  'Send a task by email to creator' => 'Sende eine Aufgabe per E-Mail an den Ersteller',
  'Send a task by email to assignee' => 'Sende eine Aufgabe per E-Mail an den Zuständigen',
  'Send email notification of impending due date' => 'Sende eine E-Mail Benachrichtigung wenn es fällig wird',
  'Send email notification of impending subtask due date' => 'Sende eine E-Mail Benachrichtigung wenn Teilaufgabe fällig wird',
  'Include Task Title and ID in subject line?' => 'Ergänze Titel und ID der Aufgabe in die E-Mail Betreffzeile',
);
