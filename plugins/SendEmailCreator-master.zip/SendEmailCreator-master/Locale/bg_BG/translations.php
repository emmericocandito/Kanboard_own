<?php

return array(
  'Email subject' => 'Тема на  имейла',
  'Duration in days' => 'Продължителност в дни',
  'Send a task by email to creator' => 'Изпращане на задача по поща до създател',
  'Send a task by email to assignee' => 'Изпращане на задача по поща до изпълнител',
  'Send email notification of impending due date' => 'Изпращане на имейл известие за наближаващ краен срок',
  'Send email notification of impending subtask due date' => 'Изпращане на имейл известие за наближаващ краен срок на подзадача',
  'Include Task Title and ID in subject line?' => 'Включване на заглавие и ID на задачата в ред с темата?',
  'Send new comments on a task by email' => 'Изпращане на нови коментари в задача по поща'
);
