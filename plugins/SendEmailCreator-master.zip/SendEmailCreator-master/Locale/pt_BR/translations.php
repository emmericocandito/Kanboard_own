<?php

return array(
  'Email subject' => 'Assunto do email',
  'Duration in days' => 'Duração em dias',
  'Send a task by email to creator' => 'Enviar uma tarefa por email para o seu criador',
  'Send a task by email to assignee' => 'Enviar uma tarefa por email para o seu responsável',
  'Send email notification of impending due date' => 'Enviar notificação por email de data de vencimento iminente',
  'Send email notification of impending subtask due date' => 'Enviar notificação por email de data de vencimento iminente de subtarefa',
);
