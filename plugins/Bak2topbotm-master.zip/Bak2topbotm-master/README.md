# bak2topbotm

Adds a back to top and bottom button to Kanboard Task Summary.

![image](https://raw.githubusercontent.com/creecros/Bak2topbotm/master/screenshot/test_buttons.gif)
