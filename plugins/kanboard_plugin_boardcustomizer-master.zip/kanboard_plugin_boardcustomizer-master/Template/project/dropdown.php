<li>
    <?= $this->url->icon('cog', t('My display settings'), 'SettingsController', 'showSettings', array('plugin' => 'boardcustomizer')) ?>
</li>