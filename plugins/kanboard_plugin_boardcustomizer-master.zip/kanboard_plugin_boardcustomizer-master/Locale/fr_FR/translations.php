<?php

return array(
    'My display settings' => 'Mes paramètres d\'affichage',
    'Board: only show first column header' => 'Tableau : Afficher une seule fois la première entête de colonne',    
    'Board: top selection without scollbar' => 'Tableau : Sélection du tableau d\'affichage dans l\'en-tête sans barre de défilement ',
    'Card: material design' => 'Carte : Aspect réaliste',
    'Card: hide task priority' => 'Carte : Masquer la priorité de la tâche',
    'Card: hide task age' => 'Carte : Masquer l\'âge de la tâche',
    'Card: white background' => 'Carte : Fond blanc',
    'Card: hide group labels' => 'Carte : Masquer le libellé "Assigné au groupe" (plugin "Group assign")',
    'Customize board and card style' => 'Personnaliser l\'aspect du tableau et des cartes',
    'Card: hide owner name' => 'Carte : Masquer le nom du propriétaire',
    'Card: hide category' => 'Carte : Masquer la catégorie',
    'Card: hide tags' => 'Carte : Masquer les étiquettes',
    'Card: hide all footer icons' => 'Carte : Masquer toutes les informations en pied (âge, priorité, avancée, etc.)',
    'Card: hide reference' => 'Carte : Masquer la référence',
    'Card: hide score' => 'Carte : Masquer la complexité',
    'Card: hide time estimated' => 'Carte : Masquer le temps estimé',
    'Card: hide task date' => 'Carte : Masquer la date d\'échance',
    'Card: hide metamagik infos' => 'Carte : Cacher les infos sur la MetaMagik',
);
