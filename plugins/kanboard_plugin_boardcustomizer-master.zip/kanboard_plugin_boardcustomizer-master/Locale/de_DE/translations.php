<?php

return array(
    'My display settings' => 'Meine Anzeigeeinstellungen',
    'Board: only show first column header' => 'Pinnwand: nur erste Spaltenüberschrift anzeigen',    
    'Board: top selection without scollbar' => 'Pinnwand: Pinnwandauswahl in Kopfzeile ohne Scrollbar',
    'Card: material design' => 'Karte: Materialdesign',
    'Card: hide task priority' => 'Karte: Aufgabenpriorität ausblenden',
    'Card: hide task age' => 'Karte: Alter der Aufgabe ausblenden',
    'Card: white background' => 'Karte: weißer Hintergrund',
    'Card: hide group labels' => 'Karte: Gruppenbeschriftungen ausblenden',
    'Customize board and card style' => 'Anpassen von Pinnwand- und Kartenstilen',
    'Card: hide owner name' => 'Karte: Name Zuständiger ausblenden',
    'Card: hide category' => 'Karte: Kategorie ausblenden',
    'Card: hide tags' => 'Karte: Schlagworte ausblenden',
    'Card: hide all footer icons' => 'Karte: alle Icons ausblenden',
    'Card: hide reference' => 'Karte: Referenz ausblenden',
    'Card: hide score' => 'Karte: Komplexität ausblenden',
    'Card: hide time estimated' => 'Karte: geschätzte Zeit ausblenden',
    'Card: hide task date' => 'Karte: Datum ausblenden',
    'Card: hide metamagik infos' => 'Karte: MetaMagik Infos ausblenden'
);
