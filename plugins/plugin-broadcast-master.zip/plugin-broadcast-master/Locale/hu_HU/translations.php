<?php

return [
    'Broadcast Message' => 'Üzenet mindenkinek',
    'Announcement' => 'Közlemény',
    'Clear message' => 'Üzenet törlése',
    'Publish' => 'Közzététel',
    'Broadcast Message by Email' => 'Üzenet mindenkinek e-mailben',
    'Send to everyone' => 'Küldés mindenkinek',
];
