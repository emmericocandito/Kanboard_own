<?php

return [
    'Broadcast Message' => 'Diffusion de messages',
    'Announcement' => 'Annonce',
    'Clear message' => 'Effacer le message',
    'Publish' => 'Publier',
    'Broadcast Message by Email' => 'Diffuser un message par email',
    'Send to everyone' => 'Envoyer à tout le monde',
];
