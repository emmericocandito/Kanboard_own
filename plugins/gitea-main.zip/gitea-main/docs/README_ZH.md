# Gitea: 文档

[![Build Status](http://drone.gitea.io/api/badges/go-gitea/docs/status.svg)](http://drone.gitea.io/go-gitea/docs)
[![Join the chat at https://img.shields.io/discord/322538954119184384.svg](https://img.shields.io/discord/322538954119184384.svg)](https://discord.gg/Gitea)
[![](https://images.microbadger.com/badges/image/gitea/docs.svg)](http://microbadger.com/images/gitea/docs "Get your own image badge on microbadger.com")

https://gitea.com/gitea/gitea-docusaurus

## 关于我们

* [维护者信息](https://github.com/orgs/go-gitea/people)
* [代码贡献者信息](https://github.com/go-gitea/docs/graphs/contributors)

## 许可证

此项目采用 Apache-2.0 许可协议，请参见 [协议文件](LICENSE) 获取更多信息。

## 版权声明

```
Copyright (c) 2016 The Gitea Authors <https://gitea.io>
```
