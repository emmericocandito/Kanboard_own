# Gitea - Docker

Dockerfile is found in root of repository.

Docker image can be found on [docker hub](https://hub.docker.com/r/gitea/gitea)

Documentation on using docker image can be found on [Gitea Docs site](https://docs.gitea.com/installation/install-with-docker-rootless)
