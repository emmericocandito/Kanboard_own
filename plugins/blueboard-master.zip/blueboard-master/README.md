Simple CSS Theme for [kanboard](https://kanboard.org/).

Download zip Archive or clone in plugins folder of you Kanboard installation.

Not so clean but do the job.

![](https://raw.githubusercontent.com/bgibout/blueboard/master/screenshot.png)

Enjoy :)

