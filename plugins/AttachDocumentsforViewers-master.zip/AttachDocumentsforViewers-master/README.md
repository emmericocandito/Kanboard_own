# AttachDocumentsforViewers in Kanboard

## What does it do?

This plugin will allow Project Viewers to attach documents to tasks.

## How to install?

Create a directory AttachDocumentsforViewers under the folder plugins

Copy all source files in this new directory.

Or install via Kanboard Plugin page



