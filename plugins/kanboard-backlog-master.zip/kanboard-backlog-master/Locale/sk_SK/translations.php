<?php

return array(
    'Plugin to add a backlog column with full height to project board' => 'Zásuvný modul, ktorý do nástenky projektu pridáva stĺpec Backlog s plnou výškou',
    'Backlog Board now activated.' => 'Nástenka Backlog aktivovaná.',
    'Backlog Board now deactivated.' => 'Nástenka Backlog deaktivovaná.',
    'Change to Normal Board' => 'Zmeniť na normálu',
    'Change to Backlog Board' => 'Zmeniť na Backlog',
);
