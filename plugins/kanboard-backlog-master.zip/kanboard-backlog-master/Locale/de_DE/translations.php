<?php

return array(
    'Plugin to add a backlog column with full height to project board' => 'Plugin um eine Backlog-Spalte mit voller Höhe zu einem Projekt Board zuzufügen',
    'Backlog Board now activated.' => 'Backlog-Spalte ist nun aktiviert.',
    'Backlog Board now deactivated.' => 'Backlog-Spalte ist jetzt deaktiviert.',
    'Change to Normal Board' => 'Zur Standard-Ansicht wechseln',
    'Change to Backlog Board' => 'Zur Backlog-Ansicht wechseln',
);

